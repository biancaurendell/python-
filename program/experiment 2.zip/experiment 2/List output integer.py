# 创建一个整数列表
numbers = [5, 2, 9, 1, 8, 3]

# 对列表进行降序排序
sorted_numbers = sorted(numbers, reverse=True)

# 输出降序排序后的列表
print("降序排列的整数列表：", sorted_numbers)
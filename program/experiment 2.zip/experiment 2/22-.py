expression = input("请输入一个表达式：")
result = eval(expression)
print("结果：", result)

s = input("请输入一个字符串：")
reversed_str = s[::-1]

print("翻转后的字符串：", reversed_str)

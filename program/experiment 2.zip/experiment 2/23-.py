num = int(input("请输入一个正整数："))
digit_sum = sum(map(int, str(num)))

print("各位数字之和：", digit_sum)
